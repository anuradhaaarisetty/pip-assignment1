import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable, Subject, concat} from 'node_modules/rxjs';


@Injectable({
  providedIn: 'root'
})
export class HealthService {
  currentTestId:number=0;
  currentequipmentId:number=0;
  customerMobile:Number;
  private _resultSource=new Subject<object>();
  result$=this._resultSource.asObservable();
  private _resultSource1=new Subject<object>();
  result1$=this._resultSource1.asObservable();
currentUser:number=0;
currentUserMailId:String="";
technicianMail:String="";
acceptmessage:string="";
  clickstatus:boolean;
  data3:any=[];
  data4:any=[];
  customers: Observable<Object>;
  result:any;
  constructor(private http:HttpClient) { }
  sendData(data){
    console.log("service accept"+data.userName);
    this._resultSource.next(data);
    console.log("details of users"+this.result$);
  }
  gettingData(data){
    console.log("welcome"+data);
    this._resultSource1.next(data);
  }
  addCustomerMobile(mobile){
    console.log("in service:"+mobile);
this.customerMobile=mobile;
  }
  addUserRegister(data:any){
    console.log("service"+data)
    let userinput={"mobileNo":data.mobile,
    "userName":data.username,
     "gender":data.gender,
     "email":data.email,
    "role":data.role,
   "password":data.password,
   "dob":data.dob
   
}


   console.log(data.mobile);
   
    return this.http.post("http://localhost:9920/userregister/adduuser",userinput);
  }

  checkMobile(mobile:number,pwd:String){
    console.log("In service");
    console.log(mobile);
    console.log(pwd);
    return this.http.get("http://localhost:9920/userregister/validatemobile/"+mobile+"/"+pwd);

  }

  acceptingbooking(usermail:string,clickingstatus:boolean){
    this.acceptmessage=usermail;
    this.clickstatus=clickingstatus;
    console.log("in service testing accepting"+this.acceptmessage)

  }
  addTest(data:any){
    let input={"testId":data.id,
    "testName":data.name,
    "testPrice":data.price,
    "testDescription":data.desc}
    console.log("in health service"+data.price)
    return this.http.post("http://localhost:9920/technicianrole/addtests",input);

};
addEquipmentservice(data:any){
  console.log("in service"+data);
  let input={"equipmentId":data.id,
"equpmentName":data.name,
"equipmentPrice":data.price}
return this.http.post("http://localhost:9920/equipment/addequipments",input);

}

 updatedEquipment(equipmentId:any,price:any){
   console.log(equipmentId+"\n"+price);
   return this.http.put("http://localhost:9920/equipment/updateequiments/"+equipmentId+"/"+price,+equipmentId);

} 

deleteTests(data:any){

  return this.http.delete("http://localhost:9920/technicianrole/deletetests/"+data);
}
deleteEquipment(id:any){
  return this.http.delete("http://localhost:9920/equipment/deletetests/"+id);
}
 getAllTechnician()
{
  return this.http.get("http://localhost:9920/managercontrol/getalltechnician");
} 


getAllTests(){
  return this.http.get("http://localhost:9920/technicianrole/getalltests");
}
getAllEquipments(){
  return this.http.get("http://localhost:9920/equipment/getallequipments");
}
getAllRoleDetails(mobile:number,password:string){
  console.log("in service role details"+mobile);
  return this.http.get("http://localhost:9920/userregister/getroledetails/"+mobile+"/"+password);
}

/* getTechnicianDetails(mobile:number,password:string){
  console.log("in technician details service"+mobile);
  return this.http.get("http://localhost:9920/managercontrol/getroledetails/"+mobile+"/"+password);

} */
getMobile(mobile){
  console.log("in service getMobile method"+mobile);
 return this.http.get("http://localhost:9920/userregister/getUserMobile/"+mobile);
 
}


setDetails(data)
{
 this.data4=data;
 console.log("setting details"+this.data4.password);
}
getAllDetails(){
  console.log("for technician ,in service"+this.data4);
  return this.data4;
}
updateTests(id:number,price:number){
  console.log("in update service"+id);
  console.log("in update service"+price);
 return this.http.put("http://localhost:9920/technicianrole/updatetests/"+id+"/"+price,+id);
}
addBooking(umail: String,tmail: String) {
  console.log("adding booking")
  console.log("user mail:"+umail);
  console.log("technician mail is:"+tmail)
  return this.http.get("http://localhost:9920/userregister/booking/"+this.customerMobile+"/"+tmail);
   
}
getBookedUsers(technicianMail: String) {
  console.log("getting booked users")
  console.log("in service booking"+technicianMail);
  return this.http.get("http://localhost:9920/userregister/getdetails/"+technicianMail);

}
}

