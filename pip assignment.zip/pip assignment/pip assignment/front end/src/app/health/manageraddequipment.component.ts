import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manageraddequipment',
  templateUrl: './manageraddequipment.component.html',
  styleUrls: ['./manageraddequipment.component.css']
})
export class ManageraddequipmentComponent implements OnInit {

  constructor(private service:HealthService,private router:Router) { }
  model:any={};
  result:boolean=false;
  addEquipment()
  { 
    console.log("in add equipments ts")
    this.service.addEquipmentservice(this.model).subscribe();
    this.router.navigate(['/managerroles'])
    
  }
  updateEquipment()
  {
    this.router.navigate(['/updatetests'])
  }
  ngOnInit() {
  }

}
