import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-updateequipment',
  templateUrl: './updateequipment.component.html',
  styleUrls: ['./updateequipment.component.css']
})
export class UpdateequipmentComponent implements OnInit {

  constructor(private service:HealthService,private router:Router) { }
  model:any
price:number;
equipmentId:number;
show:boolean=false;
result:any;
  updateEquipment(price:any){
  
  this.price=price;
  return this.service.updatedEquipment(this.equipmentId,this.price).subscribe();
  this.router.navigate(['./viewequipment']);

      
    
  
  
}

  ngOnInit() {
    this.equipmentId=this.service.currentequipmentId;
  }

}
