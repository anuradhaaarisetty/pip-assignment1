import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-managerviewequipments',
  templateUrl: './managerviewequipments.component.html',
  styleUrls: ['./managerviewequipments.component.css']
})
export class ManagerviewequipmentsComponent implements OnInit {
  data:any=[];
  result:any=[];
  show:boolean=false;
  show1:boolean=false;
  
  constructor(private service:HealthService,private router:Router) { }

  ngOnInit() {
    this.service.getAllEquipments().subscribe(result=>{this.data=result;
      console.log("data"+this.data.test)});
  }

  updateEquipments(id:any){
    console.log(id)
    this.service. currentequipmentId=id;
    this.show=true;
    this.router.navigate(['./updateequipments'])
  
  }
  
  deleteEq(id:any){
    this.show1=true;
    
    console.log("in delete tests ts file"+id);
    let index=this.data.indexOf(id);
    this.data.splice(index,1);
    window.location.reload();
      this.service.deleteEquipment(id).subscribe();
    
    }
    getAllEquipments(){
      this.service.getAllEquipments().subscribe(result=>{this.data=result;
        console.log("in manager delete tests"+this.data);
      })
      
}
}