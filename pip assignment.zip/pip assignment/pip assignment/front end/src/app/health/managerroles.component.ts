import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-managerroles',
  templateUrl: './managerroles.component.html',
  styleUrls: ['./managerroles.component.css']
})
export class ManagerrolesComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }

addTests(){
  this.router.navigate(['./managertest']);
}
addequipments(){
  this.router.navigate(['./addequipments']);
}
viewTests(){
  this.router.navigate(['./managerviewtests'])
}
viewequipments(){
  this.router.navigate(['./viewequipment'])
}

deleteTest(){
  this.router.navigate(["./ManagerdeletetestsComponent"])
}
updateTest(){
  this.router.navigate(["./UpdatetestsComponent"])
}
}
