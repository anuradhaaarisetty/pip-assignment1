import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-technicianaccept',
  templateUrl: './technicianaccept.component.html',
  styleUrls: ['./technicianaccept.component.css']
})
export class TechnicianacceptComponent implements OnInit {
  result1:any=[];
  data:any=[];
  val1:any={};
  mob:any;
  a:boolean=false;
  clickingstatus:boolean=false;
  msg:any=false;
  resulting:string="your booking is accepted"
  constructor(private service:HealthService) { }

acceptBooking(email){
  this.a=true;
  this.msg=true;
  localStorage.setItem("msg",this.msg);
this.clickingstatus=true;

  console.log("in technician")
  console.log("user mailid is:"+email)
  this.service.acceptingbooking(email,this.clickingstatus);
  
  
}

  ngOnInit() {
    console.log("in technician accept reject");
    this.mob=localStorage.getItem("mobile");
    this.service.getMobile(this.mob).subscribe(data=>{this.val1=data;
    console.log("welcome");
    });
    
     /* console.log("getting details in technician"+this.service.getBookedUsers(this.service.technicianMail))
      return this.service.getBookedUsers(this.service.technicianMail).subscribe((result1:any)=>{
        this.val1=result1;
      })
      } */
    }
    
  }