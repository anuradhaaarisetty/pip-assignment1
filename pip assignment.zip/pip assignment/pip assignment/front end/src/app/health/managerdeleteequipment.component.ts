import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-managerdeleteequipment',
  templateUrl: './managerdeleteequipment.component.html',
  styleUrls: ['./managerdeleteequipment.component.css']
})
export class ManagerdeleteequipmentComponent implements OnInit {
  data:any=[];
  result:any=[];
  
  constructor(private service:HealthService) { }
  deleteTests(id:any){
  
    console.log("in delete equipments     ts file"+id);
    let index=this.data.indexOf(id);
    this.data.splice(index,1);
      this.service.deleteEquipment(id).subscribe();
    
    }
    getAllEquipments(){
      this.service.getAllEquipments().subscribe(result=>{this.data=result;
        console.log("in manager delete Equipments"+this.data);
      })
      
    
    }

  ngOnInit() {
    this.service.getAllEquipments().subscribe(result=>{this.data=result;
      console.log("data"+this.data.equipments)});
  }

}
