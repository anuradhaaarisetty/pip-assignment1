import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 

  constructor(private service:HealthService,private router:Router) { }
model:any={}
addUser():any{
  this.service.addUserRegister(this.model).subscribe();
  this.router.navigate(['/login'])
}
  ngOnInit() {
  }

}
