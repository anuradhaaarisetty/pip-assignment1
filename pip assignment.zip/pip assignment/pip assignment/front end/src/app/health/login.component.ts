import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  result:any;
  role:any;
  mob:any;

  constructor(private service:HealthService,private router:Router) { }

check(mobile:number,password:String){
    
  console.log("login"+mobile+password);
    this.service.checkMobile(mobile,password).subscribe((data:any)=>{this.result=data;
    console.log("in ts :"+this.result);
  
    if(this.result==1)
    {
      console.log("hii manager")
    this.router.navigate(['./managerroles']);
    }
    else if(this.result==2){
      console.log("hii")
      //this.service.addCustomerMobile(mobile)
      this.router.navigate(['./technicianaccept']);
    }
   else if(this.result==3){
     console.log("in ts"+mobile);
    this.mob=mobile;
    console.log("in ts"+this.mob);
     localStorage.setItem("mobile",this.mob);
    // this.service.addCustomerMobile(mobile);
           this.router.navigate(['./customer'])
    }
    else
    
    alert("you are not registered");});
 


}

ngOnInit() {
}

}

