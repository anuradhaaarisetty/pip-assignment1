import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-managerviewtests',
  templateUrl: './managerviewtests.component.html',
  styleUrls: ['./managerviewtests.component.css']
})
export class ManagerviewtestsComponent implements OnInit {
 

  
  constructor(private service:HealthService,private router:Router) { }
  data:any=[];
  result:any=[];
  show:boolean=false;
  show1:boolean=false;
  
  addTests(){
    this.router.navigate(['/managertest'])
  }
updateTests(id:any){
  console.log(id);
  this.service.currentTestId=id;
  this.show=true;
  this.router.navigate(['/updatetests'])

}
deleteTests(id:any){
  this.show1=true;
  
  console.log("in delete tests ts file"+id);
  let index=this.data.indexOf(id);
  this.data.splice(index,1);
  window.location.reload();
    this.service.deleteTests(id).subscribe();
  
  }
  getAllTests(){
    this.service.getAllTests().subscribe(result=>{this.data=result;
      console.log("in manager delete tests"+this.data);
    })
    
  
  }
  ngOnInit() {
    this.service.getAllTests().subscribe(result=>{this.data=result;
      console.log("data"+this.data.test)});
  }
}
