import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor(private router:Router,private service:HealthService) { }

  ngOnInit() {
  }
  bookTechnician(){
    console.log("in "+this.service.currentUserMailId);
this.router.navigate(['/customeroperations'])
  }
  viewTests(){
  this.router.navigate(['/customerviewtests'])

}

}
