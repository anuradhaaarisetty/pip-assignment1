import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './health/home.component';
import { RegisterComponent } from './health/register.component';

import { ManagertestComponent } from './health/managertest.component';
import { CustomeroperationsComponent } from './health/customeroperations.component';
import { TechnicianacceptComponent} from'./health/technicianaccept.component';
import { CustomerviewtestsComponent } from './health/customerviewtests.component';
import { ManagerviewtestsComponent } from './health/managerviewtests.component';
import { ManagerdeletetestsComponent } from './health/managerdeletetests.component';
import { UpdatetestsComponent } from './health/updatetests.component';
import { LoginComponent } from './health/login.component';
import { CustomerComponent } from './health/customer.component';
import { ManagerrolesComponent } from './health/managerroles.component';
import { ManageraddequipmentComponent } from './health/manageraddequipment.component';
import { UpdateequipmentComponent } from './health/updateequipment.component';
import { ManagerviewequipmentsComponent } from './health/managerviewequipments.component';



const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'register',component:RegisterComponent},
  {path:'login',component:LoginComponent},
  {path:'customer',component:CustomerComponent},
  {path:'managerroles',component:ManagerrolesComponent},
  {path:'managertest',component:ManagertestComponent},
  {path:'customeroperations',component:CustomeroperationsComponent},
  {path:'customerviewtests',component:CustomerviewtestsComponent},
  {path:'technicianaccept',component:TechnicianacceptComponent},
  {path:'managerviewtests',component:ManagerviewtestsComponent},
  {path:'managerdeletetests',component:ManagerdeletetestsComponent},
  {path:"updateequipments",component:UpdateequipmentComponent},
  {path:"viewequipment",component:ManagerviewequipmentsComponent},
  {path:'updatetests',component:UpdatetestsComponent},
  {path:"addequipments",component:ManageraddequipmentComponent},
  /* {path:'managerupdatetests',component:ManagerupdatetestsComponent}, */
  /* {path:'manageraddequipment',component:ManageraddequipmentComponent}, */
  
 {path :'', redirectTo:'/home', pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
