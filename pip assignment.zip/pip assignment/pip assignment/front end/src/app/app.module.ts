import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './health/home.component';

import { RegisterComponent } from './health/register.component';
import {HttpClientModule} from '@angular/common/http';
import { ManagerrolesComponent } from './health/managerroles.component';
import { ManagertestComponent } from './health/managertest.component';
import { CustomeroperationsComponent } from './health/customeroperations.component';
import { TechnicianacceptComponent} from './health/technicianaccept.component';
import { CustomerviewtestsComponent } from './health/customerviewtests.component';
import { ManagerviewtestsComponent } from './health/managerviewtests.component';
import { ManagerdeletetestsComponent } from './health/managerdeletetests.component';
import { UpdatetestsComponent } from './health/updatetests.component';

import { LoginComponent } from './health/login.component';
import { CustomerComponent } from './health/customer.component';
import { ManageraddequipmentComponent } from './health/manageraddequipment.component';
import { UpdateequipmentComponent } from './health/updateequipment.component';
import { ManagerdeleteequipmentComponent } from './health/managerdeleteequipment.component';
import { ManagerviewequipmentsComponent } from './health/managerviewequipments.component';
import { HeaderComponent } from './health/header.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    
    RegisterComponent,
    ManagerrolesComponent,
    ManagertestComponent,
    CustomeroperationsComponent,
    TechnicianacceptComponent,
    CustomerviewtestsComponent,
      ManagerviewtestsComponent,
    ManagerdeletetestsComponent,
    UpdatetestsComponent,
  
    LoginComponent,
    CustomerComponent,
    ManageraddequipmentComponent,
    UpdateequipmentComponent,
    ManagerdeleteequipmentComponent,
    ManagerviewequipmentsComponent,
    HeaderComponent


  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
