package com.cg.healthcarelogistics.dao;

import java.util.List;

import com.cg.healthcarelogistics.dto.Equipment;

public interface EquipmentDao {
	public Equipment addEquipment(Equipment equipment);
	public void updateEquipment(Long equipmentId,Integer equipmentprice);
	public List<Equipment> getAllTests();
	public void deleteTest(Long equipmentId);
}
