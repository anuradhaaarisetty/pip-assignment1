package com.cg.healthcarelogistics.dao;

import java.util.List;

import com.cg.healthcarelogistics.dto.TechnicianRole;
import com.cg.healthcarelogistics.dto.UserRegistration;

public interface TechnicianRoleDao {
	public TechnicianRole addTest(TechnicianRole test);
	public void updateTest(Long testId,Integer price);
	public List<TechnicianRole> getAllTests();
	public void deleteTest(Long testId);
	public Integer billing(Long id);
		
	
}
