package com.cg.healthcarelogistics.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="equipment_operations")
public class Equipment {
	@Id
	@Indexed(name="_id")
	private Long equipmentId;
	private String equpmentName;
	private Integer equipmentPrice;
	public Equipment(){
		
	}
	public Equipment(Long equipmentId, String equpmentName, Integer equipmentPrice) {
		super();
		this.equipmentId = equipmentId;
		this.equpmentName = equpmentName;
		this.equipmentPrice = equipmentPrice;
	}
	;
	public Long getEquipmentId() {
		return equipmentId;
	}
	public void setEquipmentId(Long equipmentId) {
		this.equipmentId = equipmentId;
	}
	public String getEqupmentName() {
		return equpmentName;
	}
	public void setEqupmentName(String equpmentName) {
		this.equpmentName = equpmentName;
	}
	public Integer getEquipmentPrice() {
		return equipmentPrice;
	}
	public void setEquipmentPrice(Integer equipmentPrice) {
		this.equipmentPrice = equipmentPrice;
	}
	@Override
	public String toString() {
		return "Equipment [equipmentId=" + equipmentId + ", equpmentName=" + equpmentName + ", equipmentPrice="
				+ equipmentPrice + "]";
	}
	

}
