package com.cg.healthcarelogistics.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthcarelogistics.dao.TechnicianRoleDao;
import com.cg.healthcarelogistics.dto.TechnicianRole;
import com.cg.healthcarelogistics.dto.UserRegistration;

@Service
public class TechnicianRoleServiceImpl implements TechnicianRoleService {
@Autowired
TechnicianRoleDao technicianRoleDao;
	@Override
	public TechnicianRole addTest(TechnicianRole test) {
		// TODO Auto-generated method stub
		System.out.println("in service"+test);
		return technicianRoleDao.addTest(test);
	}

	@Override
	public void updateTest(Long testId, Integer price) {
		// TODO Auto-generated method stub
		technicianRoleDao.updateTest(testId, price);
		
	}

	@Override
	public List<TechnicianRole> getAllTests() {
		// TODO Auto-generated method stub
		return technicianRoleDao.getAllTests();
	}

	@Override
	public Integer billing(Long id) {
		
		// TODO Auto-generated method stub
		return technicianRoleDao.billing(id);
	}

	@Override
	public void deleteTest(Long testId) {
		// TODO Auto-generated method stub
		technicianRoleDao.deleteTest(testId);
	}

	
	
	

}
