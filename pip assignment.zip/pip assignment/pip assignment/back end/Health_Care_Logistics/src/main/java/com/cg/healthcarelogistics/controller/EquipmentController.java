package com.cg.healthcarelogistics.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.healthcarelogistics.dto.Equipment;


import com.cg.healthcarelogistics.service.Equipmentservice;


@RestController
@RequestMapping("/equipment")
@CrossOrigin(origins="http://localhost:4200")
public class EquipmentController {
	@Autowired
	Equipmentservice eservice;
	@PostMapping("/addequipments")
	public Equipment addequipments(@RequestBody Equipment eDetails) {
		System.out.println("in controller"+eDetails);
		return eservice.addEquipment(eDetails);
	}
	
	@PutMapping("/updateequiments/{eId}/{price}")
	public void updateequipments(@PathVariable("eId") Long equimentId,@PathVariable("price") Integer equipmentPrice ) {
		System.out.println("in update hiiiii");
		System.out.println("In update test "+equimentId);
		System.out.println("In update test "+equipmentPrice);
		eservice.updateEquipment(equimentId, equipmentPrice);
	}
	
	@GetMapping("/getallequipments")
	public List<Equipment> getAllequipments(){
		System.out.println("in controller adding tests");
		System.out.println("from controller hiii");
		return eservice.getAllTests();
	}
		
@DeleteMapping("/deletetests/{id}")
public void deleteequipments(@PathVariable("id") Long equipmentId) {
	System.out.println("delete test controller"+equipmentId);
	eservice.deleteTest(equipmentId);
}

	
}
