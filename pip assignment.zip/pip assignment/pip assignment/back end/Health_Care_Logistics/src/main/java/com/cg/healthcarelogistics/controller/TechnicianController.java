package com.cg.healthcarelogistics.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.healthcarelogistics.dto.TechnicianRole;
import com.cg.healthcarelogistics.dto.UserRegistration;
import com.cg.healthcarelogistics.service.TechnicianRoleService;

@RestController
@RequestMapping("/technicianrole")
@CrossOrigin(origins="http://localhost:4200")

public class TechnicianController {
	Integer totalPrice=0;
	@Autowired
	TechnicianRoleService technicianRoleService;
	@PostMapping("/addtests")
	public TechnicianRole addTests(@RequestBody TechnicianRole testDetails) {
		System.out.println("in controller"+testDetails);
		return technicianRoleService.addTest(testDetails);
	}
	
	@PutMapping("/updatetests/{testId}/{price}")
	public void updateTests(@PathVariable("testId") Long testId,@PathVariable("price") Integer testPrice ) {
		System.out.println("in update hiiiii");
		System.out.println("In update test "+testId);
		System.out.println("In update test "+testPrice);
		technicianRoleService.updateTest(testId, testPrice);
	}
	
	@GetMapping("/getalltests")
	public List<TechnicianRole> getAllTests(){
		System.out.println("in controller adding tests");
		System.out.println("from controller hiii");
		return technicianRoleService.getAllTests();
	}
		
	
		
	
	
	@GetMapping("/billing/{id}")
	public Integer billing(@PathVariable("id") Long[] id) {
		
		System.out.println("in billing controller"+id);
		for(Long id1:id) {
			totalPrice= technicianRoleService.billing(id1);	
		}
		return totalPrice; 
	}
	
@DeleteMapping("/deletetests/{id}")
public void deleteTests(@PathVariable("id") Long id) {
	System.out.println("delete test controller"+id);
	technicianRoleService.deleteTest(id);
}
}
