package com.cg.healthcarelogistics.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.healthcarelogistics.dto.UserRegistration;
import com.cg.healthcarelogistics.service.UserRegistrationService;

@RestController
@RequestMapping("/userregister")
@CrossOrigin(origins="http://localhost:4200")
public class UserRegistrationController {
	@Autowired
	UserRegistrationService userRegistrationService;
	
	@GetMapping("/validatemobile/{mob}/{password}")
	public Integer validateMobile(@PathVariable("mob") Long mobile,@PathVariable("password")String password) {
		return userRegistrationService.validateUserLogin(mobile,password);
	}
	
	@PostMapping("/adduuser")
	public UserRegistration addUser(@RequestBody UserRegistration user) {
		System.out.println("in controller"+user);
		return userRegistrationService.addUser(user);
	}
		
	@GetMapping("/getroledetails/{mobile}/{password}")
	public Integer getRoleDetails(@PathVariable("mobile") Long mob,@PathVariable("password") String pwd) {
		String role=userRegistrationService.getDetailsBasedOnRole(mob, pwd);
		Integer n=4;
		System.out.println("in conroller roles :"+role);
	
		if(role.equalsIgnoreCase("manager")){
			n=1;
			
		}
		if(role.equalsIgnoreCase("technician")) {
			n=2;
			
		}
			if(role.equalsIgnoreCase("customer")){
			n=3;
		}
				return n;
	}
		
		
		
	
	@GetMapping("/getalluser")
	public List<UserRegistration> getAllUserDetails(){
		return userRegistrationService.getAllUserDetails();
	}
	
	@GetMapping("/getUserMobile/{mobile}")
	public UserRegistration getUserMobile(@PathVariable("mobile") Long mobile) {
		System.out.println("final result "+userRegistrationService.getUserMobile(mobile));
		return userRegistrationService.getUserMobile(mobile);
	}
	@PostMapping("/booking/{umobile}/{tmail}")
	public String booking(@PathVariable("umobile") Long umobile,@PathVariable("tmail") String tmail) {
		System.out.println("in booking controller");
		System.out.println("booking controller"+umobile+tmail);
		int i=userRegistrationService.booking(umobile, tmail);
		if(i==1) {
			return "success";
		}
		else {
			return "unsuccess";
		}
	}
	@GetMapping("/booking/{umobile}/{tmail}")
	public Integer booking1(@PathVariable("umobile") Long umobile,@PathVariable String tmail) {
		
		System.out.println("hkheukwhuk");
		return userRegistrationService.booking(umobile, tmail);
		
	}
	
	@GetMapping("/getdetails/{tmail}")
		public List<UserRegistration> getdetails(@PathVariable("tmail") String tmail){
			return userRegistrationService.getDetails(tmail);
		}
	}


