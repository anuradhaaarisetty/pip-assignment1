package com.cg.healthcarelogistics.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthcarelogistics.dao.ManagerDao;
import com.cg.healthcarelogistics.dto.ManagerRole;
import com.cg.healthcarelogistics.dto.TechnicianRole;
import com.cg.healthcarelogistics.dto.UserRegistration;

@Service
public class ManagerServiceImpl implements ManagerService{

	@Autowired
	ManagerDao managerDao;
	@Override
	public ManagerRole addTechnician(ManagerRole managerRole) {
		// TODO Auto-generated method stub
		return managerDao.addTechnician(managerRole);
	}

	@Override
	public List<ManagerRole> getAllTechnician() {
		// TODO Auto-generated method stub
		return managerDao.getAllTechnician();
	}

	@Override
	public void updateTechnician(Long mobile, Integer salary, Integer experience) {
		// TODO Auto-generated method stub
		managerDao.updateTechnician(mobile, salary, experience);
		
	}

	@Override
	public void deleteTechnician(Long mobileNo) {
		// TODO Auto-generated method stub
		managerDao.deleteTechnician(mobileNo);
		
	}

	@Override
	public boolean getTechnicianDetails(Long mobile, String password) {
		// TODO Auto-generated method stub
		return managerDao.getTechnicianDetails(mobile, password);
	}

	
	

	
	
	
	//tests

	/*@Override
	public ManagerRole addTest(ManagerRole test) {
		// TODO Auto-generated method stub
		return managerDao.addTest(test);
	}

	@Override
	public void updateTest(Integer testId, Integer price) {
		// TODO Auto-generated method stub
		managerDao.updateTest(testId, price);
		
	}

	@Override
	public List<TechnicianRole> getAllTests() {
		// TODO Auto-generated method stub
		return managerDao.getAllTests();
	}*/
	
	
	

}
