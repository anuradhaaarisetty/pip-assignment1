package com.cg.healthcarelogistics.service;

import java.util.List;

import com.cg.healthcarelogistics.dto.ManagerRole;
import com.cg.healthcarelogistics.dto.TechnicianRole;
import com.cg.healthcarelogistics.dto.UserRegistration;

public interface ManagerService {
	public ManagerRole addTechnician(ManagerRole managerRole);
	public List<ManagerRole> getAllTechnician();
	public void updateTechnician(Long mobile,Integer salary,Integer experience);
	public void deleteTechnician(Long mobileNo);
	
	public boolean getTechnicianDetails(Long mobile,String password);
	
	
	/*public ManagerRole addTest(ManagerRole test);
	public void updateTest(Integer testId,Integer price);
	public List<ManagerRole> getAllTests();*/
}
