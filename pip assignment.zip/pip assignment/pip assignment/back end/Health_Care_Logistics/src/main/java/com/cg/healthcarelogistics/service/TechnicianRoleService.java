package com.cg.healthcarelogistics.service;

import java.util.List;

import com.cg.healthcarelogistics.dto.TechnicianRole;
import com.cg.healthcarelogistics.dto.UserRegistration;

public interface TechnicianRoleService {
	public TechnicianRole addTest(TechnicianRole test);
	public void updateTest(Long testId,Integer price);
	public List<TechnicianRole> getAllTests();
	public Integer billing(Long id);
	public void deleteTest(Long testId);
	

}
