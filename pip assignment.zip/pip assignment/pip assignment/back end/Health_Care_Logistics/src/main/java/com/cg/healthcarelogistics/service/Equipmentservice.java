package com.cg.healthcarelogistics.service;

import java.util.List;

import com.cg.healthcarelogistics.dto.Equipment;


public interface Equipmentservice {
	
public Equipment addEquipment(Equipment equipment);
public void updateEquipment(Long equipmentId,Integer equipmentprice);
public List<Equipment> getAllTests();
public void deleteTest(Long equipmentId);
	

}
