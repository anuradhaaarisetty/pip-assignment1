package com.cg.healthcarelogistics.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.healthcarelogistics.dto.UserRegistration;

import ch.qos.logback.core.net.SyslogOutputStream;


@Repository
public class UserRegistrationDaoImpl implements UserRegistrationDao{
	@Autowired
	MongoTemplate mongotemplate;

	@Override
	public Integer validateUserLogin(Long mobileNo, String password) {
		// TODO Auto-generated method stub
		boolean flag=false;
		List<UserRegistration> userRegistration=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration user:userRegistration) {
			if(user.getMobileNo().equals(mobileNo)) {
				if(user.getPassword().equals(password)) {
					if(user.getRole().equalsIgnoreCase("manager"))
						return 1;
					else if(user.getRole().equalsIgnoreCase("technician"))
						return 2;
					else
						return 3;
				}
				
			}
		}
		return 0;
	}

	@Override
	public UserRegistration addUser(UserRegistration user) {
		// TODO Auto-generated method stub
		System.out.println("dao user role"+user.getRole());
		/*if(user.getRole().equalsIgnoreCase("manager")) {
			mongotemplate.save(user);
			mongotemplate.remove(user);
			return user;
		}*/
		return mongotemplate.insert(user);
	}

	@Override
	public List<UserRegistration> getAllUserDetails() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(UserRegistration.class);
	}

	@Override
	public String getDetailsBasedOnRole(Long mobile, String password) {
		// TODO Auto-generated method stub
		System.out.println("in dao roles details"+mobile+password);
		List<UserRegistration> rolesdetails=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration details:rolesdetails) {
			System.out.println("roles"+details);
			if(details.getMobileNo().equals(mobile) && details.getPassword().equals(password))
		
			{
				System.out.println(details.getRole());
				return details.getRole();
				
			}
		}
		return null;
	}

	@Override
	public UserRegistration getUserMobile(Long mobile) {
		// TODO Auto-generated method stub
		List<UserRegistration> user=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration mobileDetails:user) {
			if(mobileDetails.getMobileNo().equals(mobile)) {
				return mobileDetails;
			}
			
		}
		return null;
	}

	@Override
	public Integer booking(Long umobile, String tmail) {
		// TODO Auto-generated method stub
		System.out.println("booking dao"+umobile+tmail);
		UserRegistration user=mongotemplate.findOne(Query.query(Criteria.where("mobileNo").is(umobile)),UserRegistration.class );
		user.setTechnicianEmail(tmail);
		mongotemplate.save(user);
		System.out.println("user mail in dao"+user.getMobileNo());
		System.out.println("technicinam mail"+user.getTechnicianEmail());
		
		return 1;
	}

	@Override
	public List<UserRegistration> getDetails(String tmail) {
		// TODO Auto-generated method stub
		List<UserRegistration> user=getAllUserDetails();
		List<UserRegistration> userdetails=new ArrayList<>();
		for(UserRegistration details:user) {
			if(details.getTechnicianEmail()!=null) {
				if(details.getTechnicianEmail().equalsIgnoreCase(tmail)){
					userdetails.add(details);
				}
			}
		}
		return userdetails;
	}
	
	
}
