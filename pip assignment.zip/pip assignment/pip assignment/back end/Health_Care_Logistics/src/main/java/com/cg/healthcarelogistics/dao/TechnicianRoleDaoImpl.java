package com.cg.healthcarelogistics.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;


import com.cg.healthcarelogistics.dto.TechnicianRole;
import com.cg.healthcarelogistics.dto.UserRegistration;

import ch.qos.logback.core.net.SyslogOutputStream;

@Repository
public class TechnicianRoleDaoImpl implements  TechnicianRoleDao{
	Integer totalPrice=0;
@Autowired
MongoTemplate mongoTemplate;
@Autowired
UserRegistrationDao userRegistrationDao;
	@Override
	public TechnicianRole addTest(TechnicianRole test) {
	
		// TODO Auto-generated method stub
		System.out.println("inn dao"+test);
		return mongoTemplate.insert(test);
	}

	@Override
	public void updateTest(Long testId, Integer price) {
		System.out.println("In update test dao"+testId);
		System.out.println("In update test dao "+price);
		// TODO Auto-generated method stub
		List<TechnicianRole> details=mongoTemplate.findAll(TechnicianRole.class);
		for(TechnicianRole testDetails:details) {
			System.out.println("test id"+testDetails.getTestId());
			if(testDetails.getTestId().equals(testId)) {
				System.out.println("in dao update");
				testDetails.setTestPrice(price);
				System.out.println("printing"+testDetails.getTestPrice());
				mongoTemplate.save(testDetails);
			}
		}
		
	}

	@Override
	public List<TechnicianRole> getAllTests() {
		// TODO Auto-generated method stub
		System.out.println("hey!!!");
		return mongoTemplate.findAll(TechnicianRole.class);
	}

	public Integer billing(Long id) {
		
		List<TechnicianRole> list=mongoTemplate.findAll(TechnicianRole.class);
		for(TechnicianRole bill:list) {
			if(bill.getTestId().equals(id)) {
				
				totalPrice=totalPrice+bill.getTestPrice();
				System.out.println("total price is"+totalPrice);
				
			}
		}
		return totalPrice;
	}

	@Override
	public void deleteTest(Long testId) {
		// TODO Auto-generated method stub
	List<TechnicianRole> data=mongoTemplate.findAll(TechnicianRole.class);
	for(TechnicianRole deletetests:data) {
		if(deletetests.getTestId().equals(testId)) {
			mongoTemplate.remove(deletetests);
		}
	}
		
	}

	
	
	
	
}
