package com.cg.healthcarelogistics.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.healthcarelogistics.dto.ManagerRole;
import com.cg.healthcarelogistics.dto.TechnicianRole;
import com.cg.healthcarelogistics.dto.UserRegistration;
import com.cg.healthcarelogistics.service.ManagerService;

@RestController
@RequestMapping("/managercontrol")
@CrossOrigin(origins="http://localhost:4200")
public class ManagerController {
	@Autowired
	ManagerService managerService;
	@PostMapping("/addtechnician")
	public ManagerRole addTechnician(@RequestBody ManagerRole managerRole) {
		return managerService.addTechnician(managerRole);
		
	}
	
	@GetMapping("/getalltechnician")
	public List<ManagerRole> getAllTechnician(){
		return managerService.getAllTechnician();	
	}
	@PutMapping("/updatetechnician/{mobileNo}/{salary}/{experience}")
	public void updateTechnician(@PathVariable("mobileNo") Long mobile,@PathVariable("salary")Integer salary,@PathVariable("experience")Integer experience) {
		System.out.println("updatated data:"+mobile+salary+experience);
	managerService.updateTechnician(mobile, salary, experience);
	}
	
	@DeleteMapping("/deletetechnician/{mobileNo}")
	public void deleteTechnician(@PathVariable("mobileNo") Long mobile) {
		managerService.deleteTechnician(mobile);
	}
	
	@GetMapping("/getroledetails/{mobile}/{password}")
	public boolean getTechnicianDetails(@PathVariable("mobile") Long mob,@PathVariable("password") String pwd) {
		boolean validUser=managerService.getTechnicianDetails(mob, pwd);
	
		if(validUser==true) {
			return true;
		}
		
			
		return false;
	}
		
		
	
	
	
	//regarding tests
	
	/*@PostMapping("/addtests")
	public ManagerRole addTests(ManagerRole test) {
		return managerService.addTechnician(test);
	}
	
	@PutMapping("/updatetests/{testId}/{price}")
	public void updateTests(@PathVariable("testId") Integer testId,@PathVariable("price") Integer testPrice ) {
		managerService.updateTest(testId, testPrice);
	}
	
	@GetMapping("/getalltests")
	public List<TechnicianRole> getAllTests(){
		return managerService.getAllTests();
		
	}*/
	


}
