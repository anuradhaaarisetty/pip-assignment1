package com.cg.healthcarelogistics.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthcarelogistics.dao.EquipmentDao;


import com.cg.healthcarelogistics.dto.Equipment;
@Service
public class EquipmentServiceImpl implements Equipmentservice {
	@Autowired
	EquipmentDao equipmentDao;
	@Override
	public Equipment addEquipment(Equipment equipment) {
		// TODO Auto-generated method stub
		
		System.out.println("in service"+equipment);
		return equipmentDao.addEquipment(equipment);
	}

	@Override
	public void updateEquipment(Long equipmentId, Integer equipmentprice) {
		equipmentDao.updateEquipment(equipmentId, equipmentprice);
		
	}

	@Override
	public List<Equipment> getAllTests() {
		// TODO Auto-generated method stub
		return equipmentDao.getAllTests();
	}

	@Override
	public void deleteTest(Long equipmentId) {
		// TODO Auto-generated method stub
		equipmentDao.deleteTest(equipmentId);
	}

}
