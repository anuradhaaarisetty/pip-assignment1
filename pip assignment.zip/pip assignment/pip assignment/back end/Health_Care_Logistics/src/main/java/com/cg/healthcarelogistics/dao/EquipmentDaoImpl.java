package com.cg.healthcarelogistics.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.healthcarelogistics.dto.Equipment;
import com.cg.healthcarelogistics.dto.TechnicianRole;
@Repository
public class EquipmentDaoImpl implements EquipmentDao{
	@Autowired
	MongoTemplate mongoTemplate;
	@Override
	public Equipment addEquipment(Equipment equipment) {
		// TODO Auto-generated method stub
		System.out.println("inn dao"+equipment);
		return mongoTemplate.insert(equipment);
		
	}

	@Override
	public void updateEquipment(Long equipmentId, Integer equipmentprice) {
		// TODO Auto-generated method stub
		System.out.println("In update test dao"+equipmentId);
		System.out.println("In update test dao "+equipmentprice);
		// TODO Auto-generated method stub
		List<Equipment> details=mongoTemplate.findAll(Equipment.class);
		for(Equipment eDetails:details) {
			System.out.println("test id"+eDetails.getEquipmentId());
			if(eDetails.getEquipmentId().equals(equipmentId)) {
				System.out.println("in dao update");
				eDetails.setEquipmentPrice(equipmentprice);
				System.out.println("printing"+eDetails.getEquipmentPrice());
				mongoTemplate.save(eDetails);
			}
		}
		
	}

	@Override
	public List<Equipment> getAllTests() {
		// TODO Auto-generated method stub
		System.out.println("hey!!!");
		return mongoTemplate.findAll(Equipment.class);
		
	}

	@Override
	public void deleteTest(Long equipmentId) {
		// TODO Auto-generated method stub
		List<Equipment> data=mongoTemplate.findAll(Equipment.class);
		for(Equipment equipments:data) {
			if(equipments.getEquipmentId().equals(equipmentId)) {
				mongoTemplate.remove(equipments);
			}
		}
		
	}

}
