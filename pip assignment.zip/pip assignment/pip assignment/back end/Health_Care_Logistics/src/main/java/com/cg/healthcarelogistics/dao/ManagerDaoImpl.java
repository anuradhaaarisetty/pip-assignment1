package com.cg.healthcarelogistics.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.healthcarelogistics.dto.ManagerRole;
import com.cg.healthcarelogistics.dto.TechnicianRole;
import com.cg.healthcarelogistics.dto.UserRegistration;
import com.mongodb.Mongo;

@Repository
public class ManagerDaoImpl implements ManagerDao {
	@Autowired
	MongoTemplate mongotemplate;

	@Override
	public ManagerRole addTechnician(ManagerRole managerRole) {
		// TODO Auto-generated method stub
		return mongotemplate.insert(managerRole);
	}

	@Override
	public List<ManagerRole> getAllTechnician() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(ManagerRole.class) ;
	}

	@Override
	public void updateTechnician(Long mobile,Integer salary, Integer experience) {
		// TODO Auto-generated method stub
		List<ManagerRole> technicianDetails=mongotemplate.findAll(ManagerRole.class);
		for(ManagerRole data:technicianDetails) {
			if(data.getMobileNo().equals(mobile)) {
				data.setSalary(salary);
				data.setExperience(experience);
				mongotemplate.save(data);
			}
		}
		
	}

	@Override
	public void deleteTechnician(Long mobileNo) {
		// TODO Auto-generated method stub
		List<ManagerRole> data3=mongotemplate.findAll(ManagerRole.class);
		for(ManagerRole data4:data3) {
			if(data4.getMobileNo().equals(mobileNo)) {
				mongotemplate.remove(data4);
			}
		}
		
		
	}
//tests
	//adding new test
	/*@Override
	public ManagerRole addTest(ManagerRole test) {
		// TODO Auto-generated method stub
		return mongotemplate.insert(test);
	}*/

	@Override
	public boolean getTechnicianDetails(Long mobile, String password) {
		// TODO Auto-generated method stub
		boolean valid=false;
		System.out.println("in dao roles details"+mobile+password);
	
		List<ManagerRole> details=mongotemplate.findAll(ManagerRole.class);
		for(ManagerRole technicianDetails:details) {
		if(technicianDetails.getMobileNo().equals(mobile)) {
				if(technicianDetails.getPassword().equals(password)) {
				valid=true;
				
				}
			}
		}
		return valid;
	}
	
	@Override
	public List<UserRegistration> getBookedUsers(Long techId) {
		// TODO Auto-generated method stub
		List<ManagerRole> details=mongotemplate.findAll(ManagerRole.class);
		List<UserRegistration> users=new ArrayList<>();
		for(ManagerRole technicianCustomer:details) {
			if(technicianCustomer.getMobileNo().equals(techId)) {
				//users.add(technicianCustomer.getCustomerMobileNo());
				List<ManagerRole> bookedUserDetails=(List<ManagerRole>) mongotemplate.findById(techId, ManagerRole.class);
				System.out.println("details of users"+bookedUserDetails);
				
			
			}
		}
		return users;
	}

	

	
	

	/*@Override
	public void updateTest(Integer testId, Integer price) {
		// TODO Auto-generated method stub
		List<ManagerRole> details=mongotemplate.findAll(ManagerRole.class);
		for(ManagerRole technician:details) {
			List<TechnicianRole> technicianRole=technician.getTechnicianRole();
			for(TechnicianRole testDetails:technicianRole) {
				if(testDetails.getTestId().equals(testId)) {
					testDetails.setTestPrice(price);
					mongotemplate.save(testDetails);
				}
				
			}
		}
		
	}

	@Override
	public List<ManagerRole> getAllTests() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(ManagerRole.class);
	}*/

}
